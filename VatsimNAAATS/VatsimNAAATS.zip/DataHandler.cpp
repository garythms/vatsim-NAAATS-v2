#include "pch.h"
#include <WinInet.h>
#pragma comment(lib, "wininet.lib")
#include "DataHandler.h"
#include "RoutesHelper.h"
#include "Constants.h"
#include <sstream>

using json = nlohmann::json;

// Flight data map
map<string, CAircraftFlightPlan> CDataHandler::flights;

// Version check URL (update to your own repo)
const string CDataHandler::PluginVersion = "https://raw.githubusercontent.com/garythms/vatsim-NAAATS-v2/master/pluginversion.txt";

// NAT Track URL - NOW USES NATTRAK API
const string CDataHandler::TrackURL = "https://nattrak.vatsim.net/api/tracks";

// DEFUNCT - kept as empty strings for compatibility
const string CDataHandler::TrackSource = "";
const string CDataHandler::GetSingleAircraft = "";
const string CDataHandler::FlightDataUpdate = "";
const string CDataHandler::PostSingleAircraft = "";

int CDataHandler::CheckPluginVersion(CPlugIn* plugin) {
	// Try and get data and pass into string
	string responseString = "";
	try {
		// Convert URL to LPCSTR type
		LPCSTR lpcURL = CDataHandler::PluginVersion.c_str();

		// Delete cache data
		DeleteUrlCacheEntry(lpcURL);

		// Download data
		CComPtr<IStream> pStream;
		HRESULT hr = URLOpenBlockingStream(NULL, lpcURL, &pStream, 0, NULL);
		// If failed
		if (FAILED(hr)) {
			int code = (int)hr;
			// Show user message
			plugin->DisplayUserMessage("vNAAATS", "Error", std::string("Failed to fetch version info. Code: ") + std::to_string(code), true, true, true, true, true);
			// Clogger
			CLogger::Log(CLogType::ERR, std::string("Could not fetch version info. Code: ") + std::to_string(code), "CDataHandler::CheckPluginVersion");
			return -1;
		}
		// Put data into buffer
		char tempBuffer[16384];
		DWORD bytesRead = 0;
		hr = pStream->Read(tempBuffer, sizeof(tempBuffer), &bytesRead);
		// Put data into string
		for (int i = 0; i < bytesRead; i++) {
			responseString += tempBuffer[i];
		}
	}
	catch (exception & e) {
		// Log to ES
		plugin->DisplayUserMessage("vNAAATS", "Error", string("Failed to fetch version info: " + string(e.what())).c_str(), true, true, true, true, true);
		// Clogger
		CLogger::Log(CLogType::EXC, "Could not fetch version info: " + string(string(e.what())), "CDataHandler::CheckPluginVersion");
		return -1;
	}



// Trim whitespace/newlines from the fetched version string (GitHub raw often includes \r\n)
auto trim_inplace = [](std::string& s) {
	while (!s.empty() && (s.back() == '\n' || s.back() == '\r' || s.back() == ' ' || s.back() == '\t'))
		s.pop_back();
	size_t i = 0;
	while (i < s.size() && (s[i] == '\n' || s[i] == '\r' || s[i] == ' ' || s[i] == '\t'))
		++i;
	if (i) s.erase(0, i);
};
trim_inplace(responseString);

	// Check version
	if (responseString != PLUGIN_VERSION) {
		// Disabled: version pop-up (was interrupting EuroScope on startup).
		// Keep a log entry so we still know an update exists.
		CLogger::Log(CLogType::INFO,
			std::string("Update available. Latest: ") + responseString + " | Current: " + PLUGIN_VERSION,
			"CDataHandler::CheckPluginVersion");
		// No modal dialog, no browser launch.
		return -1;
	}

	return -1;
}

// Helper function to parse track waypoint strings into coordinates
// Formats: "ELSIR" (named), "50/50" (50N 50W), "5230/40" (52.5N 40W)
CPosition CDataHandler::ParseTrackWaypoint(const string& waypoint) {
	CPosition pos;
	pos.m_Latitude = 0.0;
	pos.m_Longitude = 0.0;
	
	// Check if it contains a slash (coordinate format)
	size_t slashPos = waypoint.find('/');
	if (slashPos == string::npos) {
		// Named waypoint - return 0,0, RoutesHelper will resolve it
		return pos;
	}
	
	// Parse lat/lon from format like "50/50", "5230/40", "5330/30"
	string latPart = waypoint.substr(0, slashPos);
	string lonPart = waypoint.substr(slashPos + 1);
	
	try {
		double lat = 0.0;
		double lon = 0.0;
		
		// Parse latitude
		if (latPart.length() <= 2) {
			// Simple format: "50" = 50N
			lat = stod(latPart);
		}
		else if (latPart.length() == 4) {
			// Half-degree format: "5230" = 52 30' = 52.5N
			lat = stod(latPart.substr(0, 2)) + stod(latPart.substr(2, 2)) / 60.0;
		}
		else {
			lat = stod(latPart);
			if (lat > 90) lat /= 100.0;
		}
		
		// Parse longitude (always West in NAT, so negative)
		if (lonPart.length() <= 2) {
			// Simple format: "50" = 50W
			lon = -stod(lonPart);
		}
		else if (lonPart.length() == 4) {
			// Half-degree format: "5030" = 50 30' = 50.5W
			lon = -(stod(lonPart.substr(0, 2)) + stod(lonPart.substr(2, 2)) / 60.0);
		}
		else {
			lon = -stod(lonPart);
			if (lon < -180) lon /= 100.0;
		}
		
		pos.m_Latitude = lat;
		pos.m_Longitude = lon;
	}
	catch (...) {
		// Parse error - return 0,0
	}
	
	return pos;
}

int CDataHandler::PopulateLatestTrackData(CPlugIn* plugin) {
	// Try and get data and pass into string
	string responseString;
	try {
		// Convert URL to LPCSTR type
		LPCSTR lpcURL = TrackURL.c_str();

		// Delete cache data
		DeleteUrlCacheEntry(lpcURL);

		// Download data
		CComPtr<IStream> pStream;
		HRESULT hr = URLOpenBlockingStream(NULL, lpcURL, &pStream, 0, NULL);
		// If failed
		if (FAILED(hr)) {
			int code = (int)hr;
			// Show user message
			plugin->DisplayUserMessage("vNAAATS", "Error", "Track data download failed. Code: " + code, true, true, true, true, true);
			// Clogger
			CLogger::Log(CLogType::ERR, "Could not connect to natTrak tracks API. Code: " + code, "CDataHandler::PopulateLatestTrackData");
			return 1;
		}
		// Put data into buffer - increased size for natTrak response
		char tempBuffer[65536];
		DWORD bytesRead = 0;
		hr = pStream->Read(tempBuffer, sizeof(tempBuffer) - 1, &bytesRead);
		tempBuffer[bytesRead] = '\0';
		responseString = string(tempBuffer, bytesRead);
	}
	catch (exception & e) {
		// Log to ES
		plugin->DisplayUserMessage("vNAAATS", "Error", string("Failed to load NAT Track data: " + string(e.what())).c_str(), true, true, true, true, true);
		// Clogger
		CLogger::Log(CLogType::EXC, "Failed to load NAT Track data: " + string(string(e.what())), "CDataHandler::PopulateLatestTrackData");
		return 1;
	}

	// Parse the json
	try {
		// Clear old tracks
		if (!CRoutesHelper::CurrentTracks.empty()) {
			CRoutesHelper::CurrentTracks.clear();
		}

		// Parse JSON - natTrak returns array directly [...]
		auto jsonArray = json::parse(responseString);
		
		// TMI derived from valid_from date
		string currentTMI = "";
		
		for (size_t i = 0; i < jsonArray.size(); i++) {
			// Skip inactive tracks
			if (jsonArray[i].contains("active") && !jsonArray[i].at("active").get<bool>()) {
				continue;
			}
			
			// Make track
			CTrack track;

			// Identifier (natTrak uses "identifier" not "id")
			track.Identifier = jsonArray[i].at("identifier").get<string>();

			// TMI - derive from valid_from date
			if (jsonArray[i].contains("valid_from") && !jsonArray[i].at("valid_from").is_null()) {
				string validFrom = jsonArray[i].at("valid_from").get<string>();
				if (validFrom.length() >= 10) {
					currentTMI = validFrom.substr(8, 2); // Extract day
				}
			}
			track.TMI = currentTMI;
			CRoutesHelper::CurrentTMI = currentTMI;

			// Direction (natTrak uses string "east"/"west" not int)
			string dirStr = jsonArray[i].at("direction").get<string>();
			if (dirStr == "west") {
				track.Direction = CTrackDirection::WEST;
			}
			else if (dirStr == "east") {
				track.Direction = CTrackDirection::EAST;
			}
			else {
				track.Direction = CTrackDirection::UNKNOWN;
			}

			// Route - parse from "last_routeing" string
			// Format: "ELSIR 50/50 5230/40 5330/30 54/20 DOGAL BEXET"
			string routeStr = jsonArray[i].at("last_routeing").get<string>();
			vector<string> routeParts;
			CUtils::StringSplit(routeStr, ' ', &routeParts);
			
			for (const string& part : routeParts) {
				track.Route.push_back(part);
				CPosition pos = ParseTrackWaypoint(part);
				track.RouteRaw.push_back(pos);
			}

			// Flight levels - natTrak gives feet (34000), convert to FL (340)
			for (size_t j = 0; j < jsonArray[i].at("flight_levels").size(); j++) {
				int flFeet = jsonArray[i].at("flight_levels")[j].get<int>();
				track.FlightLevels.push_back(flFeet / 100);
			}

			// Validity times (natTrak uses snake_case)
			if (jsonArray[i].contains("valid_from") && !jsonArray[i].at("valid_from").is_null()) {
				track.validFrom = jsonArray[i].at("valid_from").get<string>();
			}
			if (jsonArray[i].contains("valid_to") && !jsonArray[i].at("valid_to").is_null()) {
				track.validTo = jsonArray[i].at("valid_to").get<string>();
			}

			// Push track to tracks array
			CRoutesHelper::CurrentTracks.insert(make_pair(track.Identifier, track));
		}
		
		// Success message
		string message = "Track data loaded successfully from natTrak.";
		if (!CRoutesHelper::CurrentTMI.empty()) {
			message += " TMI is " + CRoutesHelper::CurrentTMI + ".";
		}
		message += " " + to_string(CRoutesHelper::CurrentTracks.size()) + " active tracks.";
		plugin->DisplayUserMessage("Message", "vNAAATS Plugin", message.c_str(), false, false, false, false, false);
		CLogger::Log(CLogType::NORM, message, "CDataHandler::PopulateLatestTrackData");
		return 0;
	}
	catch (exception & e) {
		// User message
		plugin->DisplayUserMessage("vNAAATS", "Error", string("Failed to parse natTrak track JSON: " + string(e.what())).c_str(), true, true, true, true, true);
		// Clogger
		CLogger::Log(CLogType::EXC, "Failed to parse natTrak track JSON: " + string(e.what()), "CDataHandler::PopulateLatestTrackData");
		return 1;
	}
}

CAircraftFlightPlan* CDataHandler::GetFlightData(string callsign) {
	if (flights.find(callsign) != flights.end()) {
		return &flights.find(callsign)->second;
	}
	// Return invalid
	CAircraftFlightPlan fp;
	fp.IsValid = false;
	return &fp;
}

void CDataHandler::GetFlightData(string callsign, CAircraftFlightPlan& fp) {
	if (flights.find(callsign) != flights.end()) {
		fp = flights.find(callsign)->second;
		fp.IsValid = true;
		return;
	}
	fp.IsValid = false;
}

int CDataHandler::UpdateFlightData(CRadarScreen* screen, string callsign, bool updateRoute) {
	// Flight plan
	auto fp = flights.find(callsign);

	// If flight plan not found return non-success code
	if (fp == flights.end()) {
		return 1;
	}

	// Re-initialise the route if requested
	if (updateRoute) {
		CUtils::CAsyncData* data = new CUtils::CAsyncData();
		data->Screen = screen;
		data->Callsign = callsign;
		_beginthread(CRoutesHelper::InitialiseRoute, 0, (void*) data); // Async
	}

	// Success
	return 0;
}

int CDataHandler::CreateFlightData(CRadarScreen* screen, string callsign) {
	try {
		// Euroscope flight plan and my flight plan
		CFlightPlan fpData = screen->GetPlugIn()->FlightPlanSelect(callsign.c_str());
		CAircraftFlightPlan fp;
		// Instantiate aircraft information
		fp.Callsign = callsign;
		fp.Type = fpData.GetFlightPlanData().GetAircraftFPType();
		fp.Depart = fpData.GetFlightPlanData().GetOrigin();
		fp.Dest = fpData.GetFlightPlanData().GetDestination();
		fp.Etd = CUtils::ParseZuluTime(false, atoi(fpData.GetFlightPlanData().GetEstimatedDepartureTime()));
		fp.ExitTime = fpData.GetSectorExitMinutes();
		fp.DLStatus = "false";
		fp.Sector = string(fpData.GetTrackingControllerId()) == "" ? "-1" : fpData.GetTrackingControllerId();
		fp.CurrentMessage = nullptr;
		fp.IsRelevant = fp.ExitTime != -1 ? true : false;
		fp.IsEquipped = CUtils::IsAircraftEquipped(fpData.GetFlightPlanData().GetRemarks(), fpData.GetFlightPlanData().GetAircraftInfo(), fpData.GetFlightPlanData().GetCapibilities());
		fp.TargetMode = CUtils::GetTargetMode(screen->GetPlugIn()->RadarTargetSelect(callsign.c_str()).GetPosition().GetRadarFlags());

		// Scrape the selcal from the remarks
		string selcal = CUtils::GetSelcalCode(&fpData);
		fp.SELCAL = selcal != "" ? selcal : "N/A";

		// Get communication mode
		string comType;
		comType += toupper(fpData.GetFlightPlanData().GetCommunicationType());
		if (comType == "V") {
			comType = "VOX";
		}
		else if (comType == "T") {
			comType = "TXT";
		}
		else if (comType == "R") {
			comType = "RCV";
		}
		else {
			comType = "VOX";
		}
		fp.Communications = comType;

		// Set IsCleared
		fp.IsCleared = false;

		// Flight plan is valid
		fp.IsValid = true;

		// Add FP to map
		flights[callsign] = fp;

		// Generate route
		CUtils::CAsyncData* data = new CUtils::CAsyncData();
		data->Screen = screen;
		data->Callsign = callsign;
		_beginthread(CRoutesHelper::InitialiseRoute, 0, (void*)data); // Async

		CLogger::Log(CLogType::NORM, "Flight data object for " + callsign + " generated successfully.", "CDataHandler::CreateFlightData");

		// Success
		return 0;
	}
	catch (exception & ex) {
		CLogger::Log(CLogType::EXC, "Flight data generation for " + callsign + " failed: " + string(ex.what()), "CDataHandler::CreateFlightData");
		return 1;
	}
}

int CDataHandler::DeleteFlightData(string callsign) {
	if (flights.find(callsign) != flights.end()) {
		flights.erase(callsign);
		CLogger::Log(CLogType::NORM, "Flight data object for " + callsign + " destroyed successfully.", "CDataHandler::DeleteFlightData");
		return 0;
	}
	else {
		return 1;
	}
}

int CDataHandler::SetRoute(string callsign, vector<CWaypoint>* route, string track, CAircraftFlightPlan* copiedPlan) {
	if (copiedPlan != nullptr) {
		copiedPlan->Route.clear();
		copiedPlan->Route = *route;
		copiedPlan->Route.shrink_to_fit();

		if (track != "")
			copiedPlan->Track = track;
		else
			copiedPlan->Track = "RR";

		return 0;
	}
	if (flights.find(callsign) != flights.end()) {
		flights.find(callsign)->second.Route.clear();
		flights.find(callsign)->second.Route = *route;
		flights.find(callsign)->second.Route.shrink_to_fit();
		if (track != "")
			flights.find(callsign)->second.Track = track;
		else
			flights.find(callsign)->second.Track = "RR";

		return 0;
	}
	else {
		return 1;
	}
}

// ============================================================================
// STUB FUNCTIONS - These called the defunct vNAAATS API
// Kept for compatibility but do nothing
// ============================================================================

void CDataHandler::DownloadNetworkAircraft(void* args) {
	// REMOVED - vNAAATS API is defunct
	// EuroScope already has aircraft data via VATSIM
	if (args) {
		delete args;
	}
}

void CDataHandler::GetAllNetworkAircraft() {
	// REMOVED - vNAAATS API is defunct
}

void CDataHandler::PostNetworkAircraft(void* args) {
	// REMOVED - vNAAATS API is defunct
	// Use natTrak for oceanic clearances
	if (args) {
		CUtils::CNetworkAsyncData* data = (CUtils::CNetworkAsyncData*)args;
		if (data->FP) delete data->FP;
		delete args;
	}
}

void CDataHandler::UpdateNetworkAircraft(void* args) {
	// REMOVED - vNAAATS API is defunct
	// Use natTrak for oceanic clearances
	if (args) {
		CUtils::CNetworkAsyncData* data = (CUtils::CNetworkAsyncData*)args;
		if (data->FP) delete data->FP;
		delete args;
	}
}
