#pragma once
#include "pch.h"
#include "NAAATS.h"
#include <iostream>

#include "Constants.h"
#include "RadarDisplay.h"
#include "Utils.h"
#include "DataHandler.h"

CNAAATSPlugin::CNAAATSPlugin() : CPlugIn(COMPATIBILITY_CODE, PLUGIN_NAME.c_str(), PLUGIN_VERSION.c_str(), PLUGIN_AUTHOR.c_str(), PLUGIN_COPYRIGHT.c_str())
{
	// Register the display
	this->Register();

	// VATSIM data fetcher is now started lazily when first radar target is detected
	// This prevents interference with EuroScope's VATSIM authentication
	// See RadarDisplay::OnRefresh for the lazy start
}

CNAAATSPlugin::~CNAAATSPlugin() {
	// Stop VATSIM data fetcher
	CDataHandler::StopVatsimDataFetcher();

	// Cleanup static resources
	CCPDLCWindow::Cleanup();
}

CRadarScreen* CNAAATSPlugin::OnRadarScreenCreated(const char* sDisplayName, bool NeedRadarContent, bool GeoReferenced, bool CanBeSaved, bool CanBeCreated) 
{
	// Create new display if the display name matches the constant
	if (!strcmp(sDisplayName, DISPLAY_NAME)) {
		return new CRadarDisplay();
	}

	return nullptr;
}

void CNAAATSPlugin::Register() {
	// Register the display type and prevent normal EuroScope traffic from rendering
	RegisterDisplayType(DISPLAY_NAME, false, true, true, true);
}